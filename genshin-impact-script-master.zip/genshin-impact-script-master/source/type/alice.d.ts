export class AliceG {
  private mapOnSwitch: Record<string, string>
  namespace: 'alice'
  constructor()
  init(): void
  next(): void
  private prepare(): void
  private watch(): void
}
