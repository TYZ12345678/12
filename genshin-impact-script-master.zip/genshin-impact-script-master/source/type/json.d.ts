export class JsonG {
  read(path: string): Record<string, unknown>
}
