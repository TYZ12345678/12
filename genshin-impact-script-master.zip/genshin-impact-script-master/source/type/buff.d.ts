type Name = 'impetuous winds'

export class BuffG extends EmitterShell {
  private list: Name[]
  namespace: 'buff'
  constructor()
  private add(name: Name): void
  has(name: Name): boolean
  init(): void
  private remove(name: Name): void
  update(): void
}
