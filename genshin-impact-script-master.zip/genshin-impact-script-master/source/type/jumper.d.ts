export class JumperG extends KeyBinding {
  namespace: 'jumper'
  private tsJump: number
  constructor()
  break(): void
  init(): void
  jump(): void
}
