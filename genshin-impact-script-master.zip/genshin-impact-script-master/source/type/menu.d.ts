export class MenuG extends KeyBinding {
  namespace: 'menu'
  constructor()
  private asMap(): void
  private asMiniMenu(): void
  init(): void
}
