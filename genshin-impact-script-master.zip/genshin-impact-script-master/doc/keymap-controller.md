# Keymap

- [x] a - f
- [x] b - r-button
- [x] x - l-button
- [x] y - space

- [x] start - esc
- [x] back - tab

- [x] lb - t
- [x] rb - e

- [x] lt - r
- [x] rt - q

- [x] up - switch
- [x] down - switch
- [x] left - auto switch
- [x] right - map

- [x] left stick - wasd
- [x] right stick - camera
