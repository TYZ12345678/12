# 常见问题

## 会被封么

[#16](https://github.com/phonowell/genshin-impact-script/issues/16)

## 加群口令是什么

“我永远喜欢凝光光”。

加群前请先给我点星。
