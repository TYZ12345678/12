New character data for "Baizhu" and "Kaveh" have been added.

A new hotkey `Alt + Z` has been added to toggle the automatic gadget mode on/off. When enabled, the script will automatically use the equipped gadget.

The code has been further refactored. All hardcoded data that was previously written directly into the code has now been moved to the `data` folder in JSON format, making it easier to maintain in the future.