# FAQ

## Will it be banned

[#16](https://github.com/phonowell/genshin-impact-script/issues/16)
