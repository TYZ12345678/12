# Features

- Automatic fishing

- Automatic pickup

- Combat assistance, including skill countdown, one-button combat macro, and other multiple functions

- Key recording and replaying

- Other multiple functions, such as fast skipping of plot, background mute, etc.
